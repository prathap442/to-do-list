.. cmake-module:: ../CGAL_SetupCGAL_Qt5Dependencies.cmake
