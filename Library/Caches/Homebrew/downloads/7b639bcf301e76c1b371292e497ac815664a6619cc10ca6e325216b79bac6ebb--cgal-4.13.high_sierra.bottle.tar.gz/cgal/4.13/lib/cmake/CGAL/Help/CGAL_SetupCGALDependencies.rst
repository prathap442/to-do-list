.. cmake-module:: ../CGAL_SetupCGALDependencies.cmake
