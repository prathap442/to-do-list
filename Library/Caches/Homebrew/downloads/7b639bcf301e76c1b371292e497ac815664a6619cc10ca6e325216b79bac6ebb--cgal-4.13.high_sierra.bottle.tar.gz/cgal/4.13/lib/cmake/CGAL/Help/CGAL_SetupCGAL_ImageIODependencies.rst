.. cmake-module:: ../CGAL_SetupCGAL_ImageIODependencies.cmake
