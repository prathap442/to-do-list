.. cmake-module:: ../CGAL_SetupLEDA.cmake
