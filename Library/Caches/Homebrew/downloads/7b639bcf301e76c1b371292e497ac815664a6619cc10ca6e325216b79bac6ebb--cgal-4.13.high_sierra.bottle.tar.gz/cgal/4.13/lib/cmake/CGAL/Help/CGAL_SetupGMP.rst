.. cmake-module:: ../CGAL_SetupGMP.cmake
