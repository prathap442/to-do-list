.. cmake-module:: ../CGAL_SetupCGAL_CoreDependencies.cmake
