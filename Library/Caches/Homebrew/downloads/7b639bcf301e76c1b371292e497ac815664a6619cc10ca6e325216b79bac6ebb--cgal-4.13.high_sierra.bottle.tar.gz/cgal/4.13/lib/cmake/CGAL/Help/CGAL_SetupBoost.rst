.. cmake-module:: ../CGAL_SetupBoost.cmake
