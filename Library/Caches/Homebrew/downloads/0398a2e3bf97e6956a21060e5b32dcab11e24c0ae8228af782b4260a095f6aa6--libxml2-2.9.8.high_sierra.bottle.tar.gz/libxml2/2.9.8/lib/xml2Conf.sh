#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L@@HOMEBREW_CELLAR@@/libxml2/2.9.8/lib"
XML2_LIBS="-lxml2 -lz  -lpthread  -liconv  -lm "
XML2_INCLUDEDIR="-I@@HOMEBREW_CELLAR@@/libxml2/2.9.8/include/libxml2"
MODULE_VERSION="xml2-2.9.8"

