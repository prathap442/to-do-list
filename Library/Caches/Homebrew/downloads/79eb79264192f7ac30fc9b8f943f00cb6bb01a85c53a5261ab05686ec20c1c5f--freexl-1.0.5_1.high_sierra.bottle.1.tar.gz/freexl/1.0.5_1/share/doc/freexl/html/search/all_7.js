var searchData=
[
  ['value',['value',['../structFreeXL__CellValue__str.html#acaf7ae03285c299b05f0e345eff3c6a1',1,'FreeXL_CellValue_str']]]
];
