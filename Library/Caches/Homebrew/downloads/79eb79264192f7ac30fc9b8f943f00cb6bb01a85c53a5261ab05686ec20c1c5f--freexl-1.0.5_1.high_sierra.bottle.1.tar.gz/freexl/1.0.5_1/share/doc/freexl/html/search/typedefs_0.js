var searchData=
[
  ['freexl_5fcellvalue',['FreeXL_CellValue',['../freexl_8h.html#ad4c8972decafeabb9c7ce938644e2145',1,'freexl.h']]]
];
