var searchData=
[
  ['freexl_5fcellvalue_5fstr',['FreeXL_CellValue_str',['../structFreeXL__CellValue__str.html',1,'']]]
];
