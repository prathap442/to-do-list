var searchData=
[
  ['int_5fvalue',['int_value',['../structFreeXL__CellValue__str.html#a7dcd352478ee217f4a24e7fcff6170bb',1,'FreeXL_CellValue_str']]]
];
