This folder contains examples of Python usage and useful scripts and tools.

You should be aware that these are not Macintosh-specific but are shared
among Python on all platforms, so there are some that only run on Windows
or Unix or another platform, and/or make little sense on a Macintosh.
